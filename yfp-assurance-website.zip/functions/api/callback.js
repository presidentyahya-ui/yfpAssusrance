/**
 * /api/callback: GitHub sends the editor back here after login.
 * Exchanges the one-time code for an access token and hands it to the
 * editor window (Decap CMS) using its standard popup message protocol.
 */
export async function onRequest({ request, env }) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const cookies = request.headers.get("Cookie") || "";
  const saved = (cookies.match(/(?:^|;\s*)yfp_cms_state=([^;]+)/) || [])[1];

  let status = "error";
  let content = { message: "Sign-in failed. Please close this window and try again." };

  if (!code || !state || !saved || state !== saved) {
    content = { message: "Sign-in could not be verified (it may have expired). Please close this window and try again." };
  } else {
    try {
      const res = await fetch("https://github.com/login/oauth/access_token", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json", "User-Agent": "yfp-assurance-cms" },
        body: JSON.stringify({
          client_id: env.GITHUB_CLIENT_ID,
          client_secret: env.GITHUB_CLIENT_SECRET,
          code,
          redirect_uri: `${url.origin}/api/callback`,
        }),
      });
      const data = await res.json();
      if (data.access_token) {
        status = "success";
        content = { token: data.access_token, provider: "github" };
      } else {
        content = { message: data.error_description || "GitHub did not return a login token." };
      }
    } catch (err) {
      content = { message: "Could not reach GitHub. Please try again." };
    }
  }

  const message = `authorization:github:${status}:${JSON.stringify(content)}`;
  const text = status === "success" ? "Signed in. This window will close automatically." : content.message;
  const page = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>YFP Assurance editor sign-in</title>
<style>body{font-family:system-ui,sans-serif;background:#f7f4ee;color:#23262b;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0;padding:24px;text-align:center}</style>
</head><body><p>${text.replace(/[<>&]/g, "")}</p>
<script>
(function () {
  var origin = ${JSON.stringify(url.origin)};
  var message = ${JSON.stringify(message).replace(/</g, "\\u003c")};
  if (!window.opener) return;
  function receive(e) {
    if (e.origin !== origin) return;
    window.removeEventListener("message", receive);
    window.opener.postMessage(message, origin);
  }
  window.addEventListener("message", receive);
  window.opener.postMessage("authorizing:github", origin);
})();
</script></body></html>`;

  return new Response(page, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
      "Set-Cookie": "yfp_cms_state=; Path=/api; HttpOnly; Secure; SameSite=Lax; Max-Age=0",
    },
  });
}
