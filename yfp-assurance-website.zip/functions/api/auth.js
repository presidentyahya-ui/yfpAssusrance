/**
 * /api/auth: starts "Login with GitHub" for the website editor (/admin).
 * Runs as a Cloudflare Pages Function. Needs these environment variables
 * (Cloudflare → your Pages project → Settings → Variables and Secrets):
 *   GITHUB_CLIENT_ID      from your GitHub OAuth App
 *   GITHUB_CLIENT_SECRET  from your GitHub OAuth App (add as a Secret)
 */
export async function onRequest({ request, env }) {
  const url = new URL(request.url);
  if (!env.GITHUB_CLIENT_ID || !env.GITHUB_CLIENT_SECRET) {
    return new Response(
      "The website editor login is not configured yet. Add GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET in Cloudflare Pages settings, then redeploy.",
      { status: 500, headers: { "Content-Type": "text/plain; charset=utf-8" } }
    );
  }
  const state = crypto.randomUUID();
  const github = new URL("https://github.com/login/oauth/authorize");
  github.searchParams.set("client_id", env.GITHUB_CLIENT_ID);
  github.searchParams.set("redirect_uri", `${url.origin}/api/callback`);
  github.searchParams.set("scope", url.searchParams.get("scope") || "repo,user");
  github.searchParams.set("state", state);

  return new Response(null, {
    status: 302,
    headers: {
      Location: github.toString(),
      "Set-Cookie": `yfp_cms_state=${state}; Path=/api; HttpOnly; Secure; SameSite=Lax; Max-Age=600`,
      "Cache-Control": "no-store",
    },
  });
}
